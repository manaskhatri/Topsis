A Python package for topsis analysis

Usage

topsis3317 <dataset> <weights> <impacts>